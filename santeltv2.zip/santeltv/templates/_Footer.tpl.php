	<!-- footer -->
	<div class="container">
		<hr>
		<footer>
			<p class="muted"><small>&copy; <?php echo date('Y'); ?> SANTELTV</small></p>
		</footer>
	</div>
	</body>
</html>