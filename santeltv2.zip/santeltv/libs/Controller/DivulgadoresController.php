<?php
/** @package    SANTELTV::Controller */

/** import supporting libraries */
require_once("AppBaseController.php");
require_once("Model/Divulgadores.php");

/**
 * DivulgadoresController is the controller class for the Divulgadores object.  The
 * controller is responsible for processing input from the user, reading/updating
 * the model as necessary and displaying the appropriate view.
 *
 * @package SANTELTV::Controller
 * @author ClassBuilder
 * @version 1.0
 */
class DivulgadoresController extends AppBaseController
{

	/**
	 * Override here for any controller-specific functionality
	 *
	 * @inheritdocs
	 */
	protected function Init()
	{
		parent::Init();

		// TODO: add controller-wide bootstrap code
		
		// TODO: if authentiation is required for this entire controller, for example:
		// $this->RequirePermission(ExampleUser::$PERMISSION_USER,'SecureExample.LoginForm');
	}

	/**
	 * Displays a list view of Divulgadores objects
	 */
	public function ListView()
	{
		$this->Render();
	}

	/**
	 * API Method queries for Divulgadores records and render as JSON
	 */
	public function Query()
	{
		try
		{
			$criteria = new DivulgadoresCriteria();
			
			// TODO: this will limit results based on all properties included in the filter list 
			$filter = RequestUtil::Get('filter');
			if ($filter) $criteria->AddFilter(
				new CriteriaFilter('Id,Nome,Email,Assunto'
				, '%'.$filter.'%')
			);

			// TODO: this is generic query filtering based only on criteria properties
			foreach (array_keys($_REQUEST) as $prop)
			{
				$prop_normal = ucfirst($prop);
				$prop_equals = $prop_normal.'_Equals';

				if (property_exists($criteria, $prop_normal))
				{
					$criteria->$prop_normal = RequestUtil::Get($prop);
				}
				elseif (property_exists($criteria, $prop_equals))
				{
					// this is a convenience so that the _Equals suffix is not needed
					$criteria->$prop_equals = RequestUtil::Get($prop);
				}
			}

			$output = new stdClass();

			// if a sort order was specified then specify in the criteria
 			$output->orderBy = RequestUtil::Get('orderBy');
 			$output->orderDesc = RequestUtil::Get('orderDesc') != '';
 			if ($output->orderBy) $criteria->SetOrder($output->orderBy, $output->orderDesc);

			$page = RequestUtil::Get('page');

			if ($page != '')
			{
				// if page is specified, use this instead (at the expense of one extra count query)
				$pagesize = $this->GetDefaultPageSize();

				$divulgadoreses = $this->Phreezer->Query('Divulgadores',$criteria)->GetDataPage($page, $pagesize);
				$output->rows = $divulgadoreses->ToObjectArray(true,$this->SimpleObjectParams());
				$output->totalResults = $divulgadoreses->TotalResults;
				$output->totalPages = $divulgadoreses->TotalPages;
				$output->pageSize = $divulgadoreses->PageSize;
				$output->currentPage = $divulgadoreses->CurrentPage;
			}
			else
			{
				// return all results
				$divulgadoreses = $this->Phreezer->Query('Divulgadores',$criteria);
				$output->rows = $divulgadoreses->ToObjectArray(true, $this->SimpleObjectParams());
				$output->totalResults = count($output->rows);
				$output->totalPages = 1;
				$output->pageSize = $output->totalResults;
				$output->currentPage = 1;
			}


			$this->RenderJSON($output, $this->JSONPCallback());
		}
		catch (Exception $ex)
		{
			$this->RenderExceptionJSON($ex);
		}
	}

	/**
	 * API Method retrieves a single Divulgadores record and render as JSON
	 */
	public function Read()
	{
		try
		{
			$pk = $this->GetRouter()->GetUrlParam('id');
			$divulgadores = $this->Phreezer->Get('Divulgadores',$pk);
			$this->RenderJSON($divulgadores, $this->JSONPCallback(), true, $this->SimpleObjectParams());
		}
		catch (Exception $ex)
		{
			$this->RenderExceptionJSON($ex);
		}
	}

	/**
	 * API Method inserts a new Divulgadores record and render response as JSON
	 */
	public function Create()
	{
		try
		{
						
			$json = json_decode(RequestUtil::GetBody());

			if (!$json)
			{
				throw new Exception('The request body does not contain valid JSON');
			}

			$divulgadores = new Divulgadores($this->Phreezer);

			// TODO: any fields that should not be inserted by the user should be commented out

			// this is an auto-increment.  uncomment if updating is allowed
			// $divulgadores->Id = $this->SafeGetVal($json, 'id');

			$divulgadores->Nome = $this->SafeGetVal($json, 'nome');
			$divulgadores->Email = $this->SafeGetVal($json, 'email');
			$divulgadores->Assunto = $this->SafeGetVal($json, 'assunto');

			$divulgadores->Validate();
			$errors = $divulgadores->GetValidationErrors();

			if (count($errors) > 0)
			{
				$this->RenderErrorJSON('Please check the form for errors',$errors);
			}
			else
			{
				$divulgadores->Save();
				$this->RenderJSON($divulgadores, $this->JSONPCallback(), true, $this->SimpleObjectParams());
			}

		}
		catch (Exception $ex)
		{
			$this->RenderExceptionJSON($ex);
		}
	}

	/**
	 * API Method updates an existing Divulgadores record and render response as JSON
	 */
	public function Update()
	{
		try
		{
						
			$json = json_decode(RequestUtil::GetBody());

			if (!$json)
			{
				throw new Exception('The request body does not contain valid JSON');
			}

			$pk = $this->GetRouter()->GetUrlParam('id');
			$divulgadores = $this->Phreezer->Get('Divulgadores',$pk);

			// TODO: any fields that should not be updated by the user should be commented out

			// this is a primary key.  uncomment if updating is allowed
			// $divulgadores->Id = $this->SafeGetVal($json, 'id', $divulgadores->Id);

			$divulgadores->Nome = $this->SafeGetVal($json, 'nome', $divulgadores->Nome);
			$divulgadores->Email = $this->SafeGetVal($json, 'email', $divulgadores->Email);
			$divulgadores->Assunto = $this->SafeGetVal($json, 'assunto', $divulgadores->Assunto);

			$divulgadores->Validate();
			$errors = $divulgadores->GetValidationErrors();

			if (count($errors) > 0)
			{
				$this->RenderErrorJSON('Please check the form for errors',$errors);
			}
			else
			{
				$divulgadores->Save();
				$this->RenderJSON($divulgadores, $this->JSONPCallback(), true, $this->SimpleObjectParams());
			}


		}
		catch (Exception $ex)
		{


			$this->RenderExceptionJSON($ex);
		}
	}

	/**
	 * API Method deletes an existing Divulgadores record and render response as JSON
	 */
	public function Delete()
	{
		try
		{
						
			// TODO: if a soft delete is prefered, change this to update the deleted flag instead of hard-deleting

			$pk = $this->GetRouter()->GetUrlParam('id');
			$divulgadores = $this->Phreezer->Get('Divulgadores',$pk);

			$divulgadores->Delete();

			$output = new stdClass();

			$this->RenderJSON($output, $this->JSONPCallback());

		}
		catch (Exception $ex)
		{
			$this->RenderExceptionJSON($ex);
		}
	}
}

?>
